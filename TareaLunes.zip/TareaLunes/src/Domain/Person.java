package Domain;

public class Person {

    //Atributos
    private String iD, name, lastName, country, yearOfBirth;

    //Constructor sin parametros
    public Person() {
        this.iD = "";
        this.name = "";
        this.lastName = "";
        this.country = "";
        this.yearOfBirth = "";
    }

    //Constructor con parametros
    public Person(String iD, String name, String lastName, String country, String yearOfBirth) {
        this.iD = iD;
        this.name = name;
        this.lastName = lastName;
        this.country = country;
        this.yearOfBirth = yearOfBirth;
    }

    //Metodos Accesores
    public String getiD() {
        return iD;
    }

    public void setiD(String iD) {
        this.iD = iD;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(String yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

}
