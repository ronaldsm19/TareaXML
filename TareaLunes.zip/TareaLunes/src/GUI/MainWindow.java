package GUI;

import Domain.Person;
import Data.XMLPersonManager;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import org.jdom.JDOMException;

/**
 *
 * @author Ronald Emilio
 */
public class MainWindow implements GUI {

    private Pane root;
    private Label lblFamily, lblIDParent, lblIDPerson, lblName, lblLastName, lblxx, lblyy, lblIDMember, lblMenber2;
    private Button btnInsert, btnUpdate, btnRomove, btnRefresh;
    private TextField tfxFamily, tfxParent, tfxPerson, tfxName, tfxLastName, tfxXX, tfxYY, tfxMember, tfxMember2;
    private TableView<Person> tabla;
    XMLPersonManager manager;

    @Override
    public Pane init() {

        initializeComponents();
        locateComponents();
        addMainMenu();
        mostarTableView();
        addEventActions();
        try {
            this.manager = new XMLPersonManager("./data/my_persons.xml");
        } catch (JDOMException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
        }

//        String image = "Assets/fondo.jpg";
//        root.setStyle("-fx-background-image: url('" + image + "'); "
//                + "-fx-background-position: left top, center;"
//                + "-fx-background-repeat: no-repeat;"
//                + "-fx-background-size: cover, auto;");
        return root;
    }

    @Override
    public void initializeComponents() {
        this.root = new Pane();
        this.tabla = new TableView<>();
        this.lblFamily = new Label("Family Tree");
        this.lblIDParent = new Label("ID member parent");
        this.lblIDPerson = new Label("ID person");
        this.lblName = new Label("Name");
        this.lblLastName = new Label("Last Name");
        this.lblxx = new Label("xxxxx");
        this.lblyy = new Label("yyyyy");
        this.lblIDMember = new Label("ID Member");
        this.lblMenber2 = new Label("Member");
        this.btnInsert = new Button("Insert");
        this.btnUpdate = new Button("Update");
        this.btnRomove = new Button("Remove");
        this.btnRefresh = new Button("Refresh");

        //textFields
        this.tfxParent = new TextField();
        this.tfxPerson = new TextField();
        this.tfxName = new TextField();
        this.tfxLastName = new TextField();
        this.tfxXX = new TextField();
        this.tfxYY = new TextField();
        this.tfxMember = new TextField();
        this.tfxMember2 = new TextField();
        this.tfxFamily = new TextField();
    }

    @Override
    public void locateComponents() {
        this.lblFamily.relocate(30, 30);
        this.lblIDParent.relocate(30, 90);
        this.tfxParent.relocate(150, 90);
        this.lblIDPerson.relocate(30, 130);
        this.tfxPerson.relocate(150, 130);
        this.lblName.relocate(30, 170);
        this.tfxName.relocate(150, 170);
        this.lblLastName.relocate(30, 210);
        this.tfxLastName.relocate(150, 210);
        this.lblxx.relocate(330, 90);
        this.tfxXX.relocate(370, 90);
        this.lblyy.relocate(330, 130);
        this.tfxYY.relocate(370, 130);
        this.lblIDMember.relocate(30, 350);
        this.tfxMember.relocate(150, 350);
        this.lblMenber2.relocate(800, 130);
        this.tfxMember2.relocate(850, 130);

        this.btnInsert.relocate(150, 250);
        this.btnUpdate.relocate(250, 250);
        this.btnRomove.relocate(800, 250);
        this.btnRefresh.relocate(310, 350);
        this.tabla.relocate(30, 400);

    }

    public void mostarTableView() {

        //Crea la columna Cedula
        TableColumn Colum1 = new TableColumn("Title1");
        Colum1.setMinWidth(150);
        //Colum1.setCellValueFactory(""); //El String debe coincidir con lo que traigo del cliente

        //Crea sub columnas Nombre Completo
        TableColumn Colum2 = new TableColumn("Title2");
        Colum2.setMinWidth(150);
        Colum2.setCellValueFactory(new PropertyValueFactory<>("name")); //El String debe coincidir con lo que traigo del cliente
        //
        TableColumn Colum3 = new TableColumn("Title3");
        Colum3.setMinWidth(150);
        //telefonoColum.setCellValueFactory(new PropertyValueFactory<>("telefono")); //El String debe coincidir con lo que traigo del cliente

        TableColumn Colum4 = new TableColumn("Title4");
        Colum4.setMinWidth(150);
        //correoColum.setCellValueFactory(new PropertyValueFactory<>("correo"));

        TableColumn Colum5 = new TableColumn("Title5");
        Colum5.setMinWidth(150);
        //paisColum.setCellValueFactory(new PropertyValueFactory<>("pais"));
        TableColumn Column6 = new TableColumn("Title6");
        //direccionColumn.setCellValueFactory(new PropertyValueFactory<>("direccion")); //El String debe coincidir con lo que traigo del cliente
        Column6.setMinWidth(150);

        TableColumn colum7 = new TableColumn("Title7");
        colum7.setMinWidth(150);
        TableColumn colum8 = new TableColumn("Title8");
        colum8.setMinWidth(150);
        tabla.getColumns().addAll(Colum1, Colum2, Colum3, Colum4, Colum5, Column6, colum7, colum8);

    }//Fin mostrarTableView

    @Override
    public void addEventActions() {
        //Accion del boton insertar
        this.btnInsert.setOnAction((event) -> {

            try {
                String iDParent = tfxParent.getText();
                String iDPerson = tfxPerson.getText();
                String name = tfxName.getText();
                String lastName = tfxLastName.getText();
                String country = tfxXX.getText();
                String year = tfxYY.getText();

                //Instancia de la persona
                Person person = new Person(iDPerson, name, lastName, country, year);

                if (tfxParent.getText().equalsIgnoreCase("")==false) {

                    this.manager.addChild1(person, iDParent);

                } else {
                    
                    this.manager.insertPersons(person);

                }

                tfxParent.setText("");
                tfxPerson.setText("");
                tfxName.setText("");
                tfxLastName.setText("");
                tfxXX.setText("");
                tfxYY.setText("");
            } catch (IOException ex) {
                Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            }

        });

        //Accion del boton remover
        this.btnRomove.setOnAction((event) -> {
            try {
                String member = tfxMember2.getText();
                this.manager.delete(member);
                tfxMember2.setText("");
            } catch (IOException ex) {
                Logger.getLogger(MainWindow.class.getName()).log(Level.SEVERE, null, ex);
            }

        });
    }

    private void addMainMenu() {
        this.root.getChildren().clear();
        this.root.getChildren().addAll(this.lblFamily, this.lblIDParent, this.lblIDPerson, this.lblName, this.lblLastName, this.lblxx, this.lblyy, this.lblIDMember, this.lblMenber2, this.tfxParent,
                this.tfxPerson, this.tfxName, this.tfxLastName, this.tfxXX, this.tfxYY, this.tfxMember, this.tfxMember2, this.btnInsert, this.btnUpdate, this.btnRomove, this.btnRefresh, this.tabla, new Line(30, 290, 1250, 290), new Line(720, 30, 720, 280));

    }
}
