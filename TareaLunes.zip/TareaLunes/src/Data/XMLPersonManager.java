package Data;

import Domain.Person;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import static javax.management.Query.lt;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;

public class XMLPersonManager {

    private Document document;
    private Element root;
    private String path;

    public XMLPersonManager(String path) throws JDOMException, IOException {
        this.path = path;
        File fileStudent = new File(this.path);
        if (fileStudent.exists()) {
            //1. EL ARCHIVO YA EXISTE, ENTONCES LO CARGO DE MEMORIA

            //toma la estructura de datos y los carga en memoria
            SAXBuilder saxBuidelr = new SAXBuilder();
            saxBuidelr.setIgnoringElementContentWhitespace(true);

            //cargar en memoria
            this.document = saxBuidelr.build(this.path);
            this.root = this.document.getRootElement();
        } else {
            //2.EL NO EXISTE, ENTONCES LO CREA Y LO CARGA EN MEMORIA

            //CRAMOS EL ELEMENTO RAIZ
            this.root = new Element("persons");

            //creamos el documento
            this.document = new Document(this.root);

            //AHORA GUARDAMOS EL DOCUMENTO
            storeXML();
        }
    }//END METHOD
    //Almacenamos en disco duro nuestro documento xml en la ruta especifica

    private void storeXML() throws FileNotFoundException, IOException {
        XMLOutputter xMLOutputter = new XMLOutputter();
        xMLOutputter.output(this.document, new PrintWriter(this.path));
    }

    //metodo para insertar un estudiante nuevo
    public void insertPersons(Person person) throws IOException {
        //insertamos en el documento en memoria

        //creamos la persona
        Element ePerson = new Element("person");

        //agregamos los atributos del XML
        ePerson.setAttribute("identification", person.getiD());

        //crear el elemento nombre
        Element eName = new Element("name");
        eName.addContent(person.getName());

        //crear el elemento lastName
        Element eLastName = new Element("lastName");
        eLastName.addContent(person.getLastName());

        //crear el elemento country
        Element eCountry = new Element("country");
        eCountry.addContent(person.getCountry());

        //crear el elemento yearOfBirth
        Element eYearOfBirth = new Element("yearOfBirth");
        eYearOfBirth.addContent(person.getYearOfBirth());

        //agregamos los elementos a la persona
        ePerson.addContent(eName);
        ePerson.addContent(eLastName);
        ePerson.addContent(eCountry);
        ePerson.addContent(eYearOfBirth);

        //agregar a root
        this.root.addContent(ePerson);

        //guarde todo
        storeXML();
    }

    //metodo para obtener todos los objetos del xml
    public Person[] getAllPersons() {
        //obtenemos la cantidad de personas
        int personsQuantity = this.root.getContentSize();
        Person[] personsArray = new Person[personsQuantity];

        //obtenemos una lista con todos los elementos del root
        List elementList = this.root.getChildren();

        //recorrer la lista para ir creando el arreglo
        int count = 0;
        //for each
        for (Object currentObject : elementList) {
            //transformo de objeto a elemento
            Element currentElement = (Element) currentObject;

            //crear la persona
            Person currentPerson = new Person();
            //establezco el id
            currentPerson.setiD(
                    currentElement.getAttributeValue("identification")
            );
            //establezco el nombre
            currentPerson.setName(
                    currentElement.getChild("name").getValue()
            );
            //Establezco el last name
            currentPerson.setLastName(
                    currentElement.getChild("lastName").getValue()
            );
            //Establezco el country
            currentPerson.setCountry(
                    currentElement.getChild("country").getValue()
            );
            //Establezco el year of birth
            currentPerson.setYearOfBirth(
                    currentElement.getChild("yearOfBirth").getValue()
            );
            personsArray[count++] = currentPerson;
        }//end for
        return personsArray;
    }//fin getAllPersons

    //Metdo para eliminar un registro del xml
    public boolean delete(String identification) throws IOException {
        List listElementos = this.root.getChildren();
        int cont = 0;
        for (Object objectActual : listElementos) {
            Element elementoActual = (Element) objectActual;
            if (elementoActual.getAttributeValue("identification").equals(identification)) {
                this.root.removeContent(cont);
                storeXML();
                return true;
            }
            cont++;
        }
        return false;
    }//Fin delete

    //Metodo que agrega hijos al atributo
    public void addChild1(Person person, String idFather) throws IOException {
        List list = this.root.getChildren();
        addChild(list, -1, person, idFather);

    }//fin addChild

    public void readRecursivo() {
        List list = this.root.getChildren();
        readXML(list, -1);
    }

    public void readXML(List list, int level) {

        level++;

        if (list!=null &&list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Element currentElement = (Element) list.get(i);
                List elementList = currentElement.getChildren();
                if (elementList.size() > 0) {
                    System.out.println(level + "id: " + currentElement.getAttributeValue("indentification")
                            + " name: " + currentElement.getChild("name").getValue());
                    readXML(elementList, level);
                } else {
                    System.out.println(level + "id: " + currentElement.getAttributeValue("indentification")
                            + " name: " + currentElement.getName());
                }
            }
        }
    }//readXML

    public void addChild(List list, int level, Person person, String idFather) throws IOException {

        level++;

        if (list!=null &&list.size() > 0) {
            for (int i = 0; i < list.size(); i++) {
                Element currentElement = (Element) list.get(i);
                List elementList = currentElement.getChildren("person");
                if (elementList.size() > 0) {
                    addChild(elementList, level, person, idFather);
                }else if (currentElement.getAttributeValue("identification").equals(idFather)) {
                    //creamos la persona
                    Element ePerson = new Element("person");

                    //agregamos los atributos del XML
                    ePerson.setAttribute("identification", person.getiD());

                    //crear el elemento nombre
                    Element eName = new Element("name");
                    eName.addContent(person.getName());

                    //crear el elemento lastName
                    Element eLastName = new Element("lastName");
                    eLastName.addContent(person.getLastName());

                    //crear el elemento country
                    Element eCountry = new Element("country");
                    eCountry.addContent(person.getCountry());

                    //crear el elemento yearOfBirth
                    Element eYearOfBirth = new Element("yearOfBirth");
                    eYearOfBirth.addContent(person.getYearOfBirth());

                    //agregamos los elementos a la persona
                    ePerson.addContent(eName);
                    ePerson.addContent(eLastName);
                    ePerson.addContent(eCountry);
                    ePerson.addContent(eYearOfBirth);
                    //Se le añade la persona al elemento actual del ciclo
                    currentElement.addContent(ePerson);

                    storeXML();
                }
                
            }//for
        }//if
    }//addChild
}
