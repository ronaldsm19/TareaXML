
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import Data.XMLPersonManager;
import Domain.Person;
import java.io.IOException;
import org.jdom.JDOMException;

public class XMLPersonManagerTest {

    public XMLPersonManagerTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void hello() throws JDOMException, IOException {

        //Instancia de la clase xmlPersonManager
        XMLPersonManager manager = new XMLPersonManager("./data/my_persons.xml");

        //Instancias de las personas 
        Person p1 = new Person("1", "Bryan", "Keihl", "CR", "26/10/1995");
        Person p2 = new Person("2", "Concha", "Nacar", "CR", "6/10/1995");
        Person p3 = new Person("3", "Kenneth", "Lopez", "CR", "26/10/1995");
        Person p4 = new Person("4", "Ronald", "Sancho", "CR", "21/11/1995");
        Person p5 = new Person("5", "Pedro", "Sancho", "CR", "21/11/1995");
        Person p6 = new Person("6", "Juan", "Sancho", "CR", "21/11/1995");
        //Insertamos las personas
        manager.insertPersons(p1);
        manager.insertPersons(p2);
        manager.insertPersons(p3);
        manager.insertPersons(p4);
        
        
        manager.readRecursivo();
    }
}
